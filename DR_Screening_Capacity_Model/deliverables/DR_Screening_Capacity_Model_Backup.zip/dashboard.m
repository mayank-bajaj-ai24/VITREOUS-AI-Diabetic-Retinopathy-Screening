%DASHBOARD Open a concise visual summary after running run_simulation.
load(fullfile('results','all_results.mat'),'results');
plot_results(results);
open(fullfile('results','dashboard_summary.png'));
